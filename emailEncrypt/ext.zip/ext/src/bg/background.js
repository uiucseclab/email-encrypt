$(document).ready(function () {
  var loggedIn = true;
  if (loggedIn) {
    $(".login").hide();
    $(".encrypt").show();
  } else {
    $(".login").show();
    $(".encrypt").hide();
  }

  $(".encrypt-button").click(function () {
    var key = ["'", $(".public-key").text().split("\n").join("\\n' + '"), "'"].join("");
    chrome.tabs.executeScript(null, {code:"$('.Am.Al').each(function(i, el) {$(el).text(encryptMessage($(el).text()," + key + "))})"});
  });

  $(".decrypt-button").click(function () {
    var key = ["'", $(".private-key").text().split("\n").join("\\n' + '"), "'"].join("");
    var cb = function (emails) {
      console.log(JSON.parse(emails));
    }
    chrome.tabs.sendMessage(tab.id, {}, cb);

    chrome.tabs.executeScript(null, {code:"$('.h7 .a3s').each(function(i, el) {$(el).text(decryptMessage($(el).text()," + key + "))})"});
    chrome.tabs.executeScript(null, {code:"$('.h7 .Am.Al').each(function(i, el) {$(el).text(decryptMessage($(el).text()," + key + "))})"});
  });
});
