chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
    /* If the received message has the expected format... */
    if (msg.text) {
      sendResponse(JSON.stringify($(".h7 .gD").toArray().map(function (a) { return $(a).attr("email"); })));
    }
});

function encryptMessage (string, key) {
  var encrypt = new JSEncrypt();
  encrypt.setPublicKey(key);
  return encrypt.encrypt(string) && string.length ? encrypt.encrypt(string) : string;
}

function decryptMessage (string, key) {
  var decrypt = new JSEncrypt();
  decrypt.setPrivateKey(key);
  return decrypt.decrypt(string) && string.length ? decrypt.decrypt(string) : string;
}